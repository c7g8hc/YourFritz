#!/bin/bash

# Define the base directory for the project
BASE_DIR="terraform"

# Create the folder structure
mkdir -p "$BASE_DIR/modules/ami_finder"
mkdir -p "$BASE_DIR/modules/ec2_instance"

# Create files in the "ami_finder" module
touch "$BASE_DIR/modules/ami_finder/main.tf"
touch "$BASE_DIR/modules/ami_finder/variables.tf"
touch "$BASE_DIR/modules/ami_finder/outputs.tf"

# Create files in the "ec2_instance" module
touch "$BASE_DIR/modules/ec2_instance/main.tf"
touch "$BASE_DIR/modules/ec2_instance/variables.tf"
touch "$BASE_DIR/modules/ec2_instance/outputs.tf"

# Create the main Terraform configuration files
touch "$BASE_DIR/main.tf"
touch "$BASE_DIR/variables.tf"
touch "$BASE_DIR/provider.tf"
touch "$BASE_DIR/terraform.tfvars"

# Output confirmation message
echo "Directory structure and files have been created!"


